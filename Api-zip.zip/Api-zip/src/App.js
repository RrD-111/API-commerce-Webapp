import "./App.css";
import Header from "./components/Header";
import { BrowserRouter, Route } from "react-router-dom";
import Home from "./components/Home";
import Cart from "./components/Cart";
import checkout from "./components/checkout";
import Login from "./components/Login";
import SignUp from "./components/Signup";

function App() {
  return (
    <BrowserRouter>
      <Header />
      <Route path="/" exact>
      <Login />
      </Route>
      <Route path="/signup" exact>
      <SignUp />
      </Route>
   
      <div className="App">
        <Route path="/home" exact>
          <Home />
        </Route>
        <Route path="/cart">
          <Cart />
        </Route>
        <Route exact path="/checkout" component={checkout} />
      </div>
    </BrowserRouter>
  );
}

export default App;
