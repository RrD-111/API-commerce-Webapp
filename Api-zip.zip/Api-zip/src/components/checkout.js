import React, { useState } from "react";
import ThankYou from "./ThankYou";
import {Button} from '@material-ui/core';
import { useHistory, useLocation } from "react-router-dom";


const Checkout = () => {
    const [isConfirmed, setIsConfirmed] = useState(false);
    const history = useHistory();
    const location = useLocation();
    const queryParams = new URLSearchParams(location.search);
    const total = queryParams.get("total") || 0;
  

  const handleConfirmClick = () => {
    setIsConfirmed(true);
  };


  const handleBackToCartClick = () => {
    history.push("/cart"); // Navigate back to the cart page
  };

  return (
    <div style={{ textAlign: "center" }}>
      <h2>Checkout</h2>
      {isConfirmed ? (
        <ThankYou total={total} />
      ) : (
        <div>
          {total > 0 ? ( // Check if total is greater than 0
            <div>
              <h2>Total: Rs {total}/-</h2>
              <Button size="medium" color="primary" variant="contained" onClick={handleConfirmClick}>Confirm Order</Button>
              <p></p>
            </div>
          ) : (
            <p>Your cart is empty. Please add items to your cart.</p>
          )}
          <Button size="medium" color="primary" variant="contained" onClick={handleBackToCartClick}>Back to Cart</Button>
        </div>
      )}
    </div>
  );
};

export default Checkout;
