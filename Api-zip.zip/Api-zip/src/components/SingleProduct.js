import { CartState } from "../Context";
import {Button} from '@material-ui/core';

const SingleProduct = ({ prod }) => {
  const { cart, setCart } = CartState();

  return (
    <div className="products">
      <img src={prod.image} alt={prod.name} />
      <div className="productDesc">
        <span style={{ fontWeight: 700 }}>{prod.name}</span>
        <span>₹ {prod.price.substring(0, 3)}</span>
      </div>
      {cart.includes(prod) ? (
        <Button
        color="secondary" variant="contained"
          className="add remove"
          onClick={() => setCart(cart.filter((c) => c.id !== prod.id))}
        >
          Remove from Cart
        </Button>
      ) : (
        <Button color="primary" variant="contained" className="add" onClick={() => setCart([...cart, prod])}>
          Add to Cart
        </Button>
      )}
    </div>
  );
};

export default SingleProduct;
